import React, { useMemo, useState } from 'react'
import Chart from '../components/Chart'
import { MetricCard, Section, StatusPill } from '../components/Ui'

const num = x => Number(x || 0).toFixed(3)

const snapshotLabels = {
  population: 'Популяция',
  generation: 'Поколение',
  capacity: 'Экологическая ёмкость',
  avg_energy: 'Средняя энергия',
  avg_health: 'Среднее здоровье',
  entropy: 'Энтропия',
}

export default function Analytics({ state }) {
  const [tab, setTab] = useState('overview')
  const actionStats = useMemo(() => {
    const map = {}
    for (const o of state.organisms) map[o.lastAction] = (map[o.lastAction] || 0) + 1
    return Object.entries(map).sort((a,b) => b[1] - a[1])
  }, [state.organisms])

  return (
    <div className="page-grid">
      <div className="hero-row"><div><div className="page-kicker">АНАЛИТИКА · ИСТОРИЯ В РЕАЛЬНОМ ВРЕМЕНИ</div><h2 className="page-title">Что происходит внутри системы</h2><p className="page-description">Метрики отделены от симуляционного ядра и строятся по фактической истории тиков.</p></div><StatusPill>{state.history.length} точек истории</StatusPill></div>
      <div className="metric-grid analytics-cards">
        <MetricCard label="Эффективность" value={num(state.metrics.efficiency)} detail="успешность действий" tone="blue" icon="E" />
        <MetricCard label="Задержка" value={num(state.metrics.latency)} detail="условная задержка выбора" tone="dark" icon="T" />
        <MetricCard label="Разнообразие" value={num(state.metrics.diversity)} detail="генетическое расстояние" tone="cyan" icon="D" />
        <MetricCard label="Энтропия" value={num(state.metrics.entropy)} detail="распределение стратегий" tone="purple" icon="H" />
      </div>
      <Section title="История симуляции">
        <Chart history={state.history} />
      </Section>
      <div className="two-column">
        <Section title="Активные стратегии" subtitle="Последнее действие живых организмов">
          <div className="rank-list">
            {actionStats.map(([name, count], i) => <div key={name} className="rank-row"><span className="rank-num">0{i+1}</span><span>{name}</span><b>{count}</b></div>)}
            {!actionStats.length && <div className="muted">Нет данных.</div>}
          </div>
        </Section>
        <Section title="Сравнение эксперимента" subtitle="Начальный снимок и последний доступный финальный снимок">
          {state.snapshots.after ? <div className="comparison-grid">{Object.entries(state.snapshots.delta || {}).map(([key, value]) => <div key={key} className="compare-item"><span>{snapshotLabels[key] || key}</span><strong className={value >= 0 ? 'delta-up' : 'delta-down'}>{value >= 0 ? '+' : ''}{value}</strong></div>)}</div> : <div className="empty-inline">Финальный снимок появляется при остановке/рубежной точке эксперимента.</div>}
        </Section>
      </div>
      <Section title="Интерпретация" subtitle="Что означают показатели">
        <div className="interpret-grid">
          {tab === 'overview' ? <><div><b>Мощность</b><p>Комбинация среднего здоровья и энергии популяции.</p></div><div><b>Эффективность</b><p>Средний положительный эффект действий организмов.</p></div><div><b>Энтропия</b><p>Разнообразие распределения последних стратегий.</p></div><div><b>Разнообразие</b><p>Средняя генетическая дистанция между организмами.</p></div></> : <div><b>Воспроизводимость</b><p>Экспорт JSON содержит настройки, популяцию, историю и журнал.</p></div>}
        </div>
        <button className="text-link" onClick={() => setTab(tab === 'overview' ? 'repro' : 'overview')}>{tab === 'overview' ? 'Показать примечание об экспорте →' : 'Вернуться к метрикам →'}</button>
      </Section>
    </div>
  )
}
