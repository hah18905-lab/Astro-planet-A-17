import React, { useEffect, useMemo, useState } from 'react'
import PlanetMap from '../components/PlanetMap'
import Chart from '../components/Chart'
import { ActionButton, MetricCard, Progress, Section, SliderField, StatusPill } from '../components/Ui'
import { environmentFields, environmentPresets, presetDescriptions, toApiSettings } from '../config/environment'

const fmt = value => Number(value || 0).toFixed(2)

export default function Dashboard({ state, onSelect, onStorm, onClimate, onStep, onReset, onPage, onApplyEnvironment, onApplyStartEnvironment, onApplyPauseEnvironment }) {
  const p = state.planet
  const [draft, setDraft] = useState(toApiSettings(state.settings))
  const [dirty, setDirty] = useState(false)

  useEffect(() => {
    if (!dirty) setDraft(toApiSettings(state.settings))
  }, [state.settings, dirty])

  const setEnvironment = (key, value) => {
    setDraft(current => ({ ...current, [key]: value }))
    setDirty(true)
  }

  const applyPreset = name => {
    setDraft(current => ({ ...current, ...environmentPresets[name] }))
    setDirty(true)
  }

  const resetDraft = () => {
    setDraft(toApiSettings(state.settings))
    setDirty(false)
  }

  const apiSettings = useMemo(() => toApiSettings(draft), [draft])

  const currentValues = {
    temperature: p.temperature / 100,
    water: p.water / 100,
    resources: p.resources / 100,
    radiation: p.radiation / 100,
    energy: p.energy / 100,
    stability: p.stability / 100,
    solar_activity: p.solarActivity / 100,
  }

  return (
    <div className="page-grid">
      <div className="hero-row">
        <div>
          <div className="page-kicker">ЭКСПЕРИМЕНТ · {state.running ? 'В РАБОТЕ' : 'ПАУЗА'}</div>
          <h2 className="page-title">Наблюдение и управление средой</h2>
          <p className="page-description">Изменяйте условия прямо во время подготовки эксперимента, затем применяйте их и запускайте новую симуляцию.</p>
        </div>
        <StatusPill tone={dirty ? 'warn' : state.environmentStatus === 'БЛАГОПРИЯТНАЯ' ? 'good' : state.environmentStatus === 'КРИТИЧЕСКАЯ' ? 'danger' : 'warn'}>
          {dirty ? 'ЕСТЬ НЕПРИМЕНЁННЫЕ ИЗМЕНЕНИЯ' : state.environmentStatus}
        </StatusPill>
      </div>

      <div className="metric-grid">
        <MetricCard label="Популяция" value={`${p.population} / ${p.capacity}`} detail={`+${p.births} рождений · −${p.deaths} смертей`} icon="◉" />
        <MetricCard label="Поколение" value={p.generation} detail={`тик ${p.tick}`} tone="dark" icon="G" />
        <MetricCard label="Мощность" value={fmt(state.metrics.power)} detail="интегральное состояние" tone="cyan" icon="P" />
        <MetricCard label="Энтропия" value={fmt(state.metrics.entropy)} detail="разнообразие поведения" tone="purple" icon="S" />
      </div>

      <div className="dashboard-main">
        <Section title="Карта планеты" subtitle="18 × 12 клеток · клик по организму открывает профиль" className="map-section">
          <PlanetMap
            cells={state.cells}
            organisms={state.organisms}
            selectedId={state.selectedId}
            onSelect={onSelect}
            onCellClick={(_cell, stack) => {
              if (!stack?.length) return
              const current = stack.findIndex(o => o.id === state.selectedId)
              onSelect(stack[(current + 1) % stack.length].id)
            }}
          />
        </Section>

        <Section
          title="Состояние среды"
          subtitle="Выберите готовый сценарий или настройте каждый параметр вручную"
          className="state-section"
          action={<StatusPill tone={dirty ? 'warn' : 'neutral'}>{dirty ? 'ЧЕРНОВИК' : 'СИНХРОНИЗИРОВАНО'}</StatusPill>}
        >
          <div className="environment-presets-inline">
            {Object.keys(environmentPresets).map(name => (
              <button
                key={name}
                type="button"
                className="environment-preset-chip"
                onClick={() => applyPreset(name)}
                title={presetDescriptions[name]}
              >
                {name}
              </button>
            ))}
          </div>

          <div className="environment-editor">
            {environmentFields.map(([key, label, hint]) => (
              <SliderField
                key={key}
                label={label}
                value={Math.round((Number(draft[key]) || 0) * 100)}
                onChange={v => setEnvironment(key, v / 100)}
                hint={hint}
              />
            ))}
          </div>

          <div className="environment-preview">
            <div>
              <span>ТЕКУЩАЯ СРЕДА</span>
              <strong>{state.environmentStatus}</strong>
            </div>
            <div>
              <span>ПОДГОТОВЛЕНО</span>
              <strong>{dirty ? 'НОВЫЙ НАБОР УСЛОВИЙ' : 'БЕЗ ИЗМЕНЕНИЙ'}</strong>
            </div>
          </div>

          <div className="environment-compare">
            {environmentFields.map(([key, label]) => {
              const draftValue = Math.round((Number(draft[key]) || 0) * 100)
              const currentValue = Math.round((Number(currentValues[key]) || 0) * 100)
              const delta = draftValue - currentValue
              return (
                <div key={key} className="environment-compare-row">
                  <span>{label}</span>
                  <b>{currentValue}% → {draftValue}%</b>
                  {delta !== 0 && <em className={delta > 0 ? 'delta-up' : 'delta-down'}>{delta > 0 ? '+' : ''}{delta}%</em>}
                </div>
              )
            })}
          </div>

          <div className="environment-actions">
            <ActionButton variant="blue" onClick={() => onApplyStartEnvironment(apiSettings)}>Применить и ▶ запустить</ActionButton>
            <ActionButton onClick={() => onApplyPauseEnvironment(apiSettings)}>Применить и начать с паузы</ActionButton>
            <ActionButton onClick={() => onApplyEnvironment(apiSettings)} disabled={!dirty}>Применить без сброса</ActionButton>
            <ActionButton onClick={resetDraft} disabled={!dirty}>Сбросить изменения</ActionButton>
          </div>

          <div className="editor-note">
            После изменения ползунков ядро ASTRA не меняется мгновенно: параметры остаются в черновике до применения. Кнопка «Применить и ▶ запустить» создаёт новый эксперимент с выбранными условиями.
          </div>

          <div className="event-box"><span>СОБЫТИЕ</span><b>{p.event || 'Нет активного события'}</b></div>
          <div className="button-grid">
            <ActionButton onClick={onStep}>⏭ Один шаг</ActionButton>
            <ActionButton onClick={onReset}>⟳ Новый эксперимент</ActionButton>
            <ActionButton onClick={() => onStorm()} variant="blue">☀ Солнечная буря</ActionButton>
            <ActionButton onClick={() => onClimate()} variant="danger-soft">☄ Смещение климата</ActionButton>
          </div>
          <button className="text-link" onClick={() => onPage('constructor')}>Открыть полный конструктор условий →</button>
        </Section>
      </div>

      <Section title="Динамика" subtitle="Популяция, экологическая ёмкость и поколения во времени">
        <Chart history={state.history} />
      </Section>

      <Section title="Краткая информация о программе" subtitle="Коротко о задаче ASTRA">
        <div className="project-summary">ASTRA — интерактивный симулятор экосистемы планеты A-17. Физические условия среды формируют потребности организмов, а система выбора сравнивает возможные действия с учётом состояния, памяти и генома. Результаты действий влияют на выживание, адаптацию, размножение и эволюцию популяции. Серия выборочных запусков позволяет проверить, как устойчиво меняется поведение при одинаковых или изменённых условиях.</div>
      </Section>
    </div>
  )
}
