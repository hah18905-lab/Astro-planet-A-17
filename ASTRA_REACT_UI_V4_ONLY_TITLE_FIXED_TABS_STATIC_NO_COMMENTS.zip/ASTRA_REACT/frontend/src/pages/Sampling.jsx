import React, { useEffect, useMemo, useState } from 'react'
import { ActionButton, MetricCard, NumericField, Section, SliderField, StatusPill } from '../components/Ui'
import { environmentFields, environmentPresets, presetDescriptions, toApiSettings } from '../config/environment'

const labels = {
  population: 'Популяция',
  births: 'Рождения',
  deaths: 'Смерти',
  generation: 'Поколение',
  power: 'Мощность',
  efficiency: 'Эффективность',
  entropy: 'Энтропия',
  latency: 'Задержка',
  diversity: 'Разнообразие',
}

const pct = value => `${(Number(value || 0) * 100).toFixed(1)}%`
const num = value => Number(value || 0).toFixed(2)

export default function Sampling({ state, result, onRun, busy, onExport }) {
  const [settings, setSettings] = useState(() => toApiSettings(state.settings))
  const [runs, setRuns] = useState(12)
  const [ticks, setTicks] = useState(800)
  const [seed, setSeed] = useState(Number(state.settings.seed ?? state.planet.seed ?? 20260920))
  const [dirty, setDirty] = useState(false)

  useEffect(() => {
    if (!dirty) {
      setSettings(toApiSettings(state.settings))
      setSeed(Number(state.settings.seed ?? state.planet.seed ?? 20260920))
    }
  }, [state.settings, state.planet.seed, dirty])

  const set = (key, value) => {
    setSettings(current => ({ ...current, [key]: value }))
    setDirty(true)
  }

  const applyPreset = name => {
    setSettings(current => ({ ...current, ...environmentPresets[name] }))
    setDirty(true)
  }

  const resetDraft = () => {
    setSettings(toApiSettings(state.settings))
    setSeed(Number(state.settings.seed ?? state.planet.seed ?? 20260920))
    setDirty(false)
  }

  const payload = useMemo(() => ({
    settings: { ...toApiSettings(settings), seed },
    runs: Math.max(2, Math.round(runs)),
    ticks: Math.max(50, Math.round(ticks)),
    seed: Math.max(0, Math.round(seed)),
  }), [settings, runs, ticks, seed])

  const submit = async () => {
    await onRun(payload)
    setDirty(false)
  }

  return (
    <div className="page-grid">
      <div className="hero-row">
        <div>
          <div className="page-kicker">ЭКСПЕРИМЕНТ · ВЫБОРКА</div>
          <h2 className="page-title">Серия независимых запусков</h2>
          <p className="page-description">Одинаковые условия запускаются многократно с разными начальными числами.  ASTRA считает среднее, диапазон и разброс результатов и показывает распределение последних решений.</p>
        </div>
        <StatusPill tone={result?.reproducibility?.verified ? 'good' : 'neutral'}>
          {result ? (result.reproducibility?.verified ? 'ВОСПРОИЗВОДИМОСТЬ ПОДТВЕРЖДЕНА' : 'РЕЗУЛЬТАТ ПОЛУЧЕН') : 'ГОТОВО К ЗАПУСКУ'}
        </StatusPill>
      </div>

      <div className="sampling-config-grid">
        <Section title="Параметры выборки" subtitle="Это не меняет текущую симуляцию: серия считается отдельно.">
          <div className="sampling-controls-grid">
            <SliderField label="Количество запусков" value={runs} min={2} max={50} step={1} suffix="" onChange={setRuns} hint="чем больше запусков, тем стабильнее оценка среднего" />
            <SliderField label="Длительность запуска" value={ticks} min={50} max={3000} step={50} suffix=" тиков" onChange={setTicks} hint="каждый запуск идёт до этого количества тиков или до вымирания" />
          </div>
          <div className="sampling-seed-row">
            <NumericField label="Базовое начальное число" value={seed} min={0} max={2147483647} onChange={value => { setSeed(Math.max(0, Math.round(value || 0))); setDirty(true) }} hint="Запуск №1 получает это число, далее к нему прибавляется 1 для каждого следующего запуска." />
            <div className="seed-preview"><span>Диапазон начальных чисел</span><b>{seed} → {(seed + Math.max(1, runs - 1)) % 2147483648}</b><small>одна серия = фиксированная последовательность случайных состояний</small></div>
          </div>
        </Section>

        <Section title="Среда серии" subtitle="Выберите пресет, затем при необходимости измените значения вручную.">
          <div className="preset-grid compact-presets">
            {Object.keys(environmentPresets).map(name => (
              <button key={name} type="button" className="preset-button" onClick={() => applyPreset(name)} title={presetDescriptions[name]}>
                <span>{name}</span><small>{presetDescriptions[name]}</small>
              </button>
            ))}
          </div>
          <div className="sampling-environment-grid">
            {environmentFields.map(([key, label, hint]) => (
              <SliderField key={key} label={label} value={Math.round((Number(settings[key]) || 0) * 100)} onChange={v => set(key, v / 100)} hint={hint} />
            ))}
          </div>
          <div className="sampling-settings-note">
            <b>Начальная популяция</b><span>{settings.initial_population} организмов</span>
            <b>Сила мутации</b><span>{(Number(settings.mutation_strength) * 100).toFixed(1)}%</span>
          </div>
        </Section>
      </div>

      <Section title="Запуск выборки" subtitle="Серия не сбрасывает и не меняет текущую живую симуляцию.">
        <div className="sampling-runbar">
          <div className="sampling-run-info">
            <span>ПЛАН</span>
            <strong>{runs} запусков × {ticks} тиков</strong>
            <small>начальные числа {seed} … {(seed + runs - 1) % 2147483648}</small>
          </div>
          <div className="sampling-actions">
            <ActionButton variant="blue" onClick={submit} disabled={busy}>{busy ? '⟳ РАСЧЁТ СЕРИИ…' : '▶ СЧИТАТЬ ВЫБОРКУ'}</ActionButton>
            <ActionButton onClick={resetDraft} disabled={busy || !dirty}>Сбросить условия</ActionButton>
            {result && <ActionButton onClick={onExport}>↓ Экспорт выборки JSON</ActionButton>}
          </div>
        </div>
        {busy && <div className="sampling-progress-note">Симуляционное ядро сейчас выполняет независимые эксперименты. Текущая симуляция продолжает сохранять своё состояние отдельно.</div>}
      </Section>

      {!result ? (
        <Section title="Результаты появятся здесь" subtitle="После первого запуска ASTRA покажет средние значения, разброс и распределение стратегий.">
          <div className="sampling-empty"><div className="sampling-empty-mark">Σ</div><strong>Сформируйте выборку</strong><span>Для защиты проекта особенно полезно сравнивать одну и ту же среду на серии независимых запусков.</span></div>
        </Section>
      ) : (
        <>
          <div className="metric-grid sampling-metrics">
            <MetricCard label="Средняя популяция" value={num(result.summary.population.mean)} detail={`min ${num(result.summary.population.min)} · max ${num(result.summary.population.max)}`} icon="◉" />
            <MetricCard label="Средняя эффективность" value={pct(result.summary.efficiency.mean)} detail={`σ ${pct(result.summary.efficiency.std)}`} tone="cyan" icon="E" />
            <MetricCard label="Средняя энтропия" value={num(result.summary.entropy.mean)} detail={`σ ${num(result.summary.entropy.std)}`} tone="purple" icon="H" />
            <MetricCard label="Поколение" value={num(result.summary.generation.mean)} detail={`max ${num(result.summary.generation.max)}`} tone="dark" icon="G" />
          </div>

          <div className="two-column">
            <Section title="Статистика серии" subtitle={`Среднее / минимум / максимум / стандартное отклонение · ${result.runs} запусков`}>
              <div className="sampling-stat-table">
                <div className="sampling-stat-head"><span>Показатель</span><span>Среднее</span><span>Мин</span><span>Макс</span><span>σ</span></div>
                {Object.entries(result.summary).map(([key, row]) => (
                  <div className="sampling-stat-row" key={key}>
                    <span>{labels[key] || key}</span><b>{num(row.mean)}</b><span>{num(row.min)}</span><span>{num(row.max)}</span><span>{num(row.std)}</span>
                  </div>
                ))}
              </div>
            </Section>

            <Section title="Распределение решений" subtitle="Последнее действие живых организмов, объединённое по всем запускам">
              <div className="action-share-list">
                {result.actionShare.length ? result.actionShare.map((row, index) => (
                  <div className={`action-share-row ${index === 0 ? 'top' : ''}`} key={row.action}>
                    <div><span>{String(index + 1).padStart(2, '0')}</span><b>{row.action}</b></div>
                    <div className="share-track"><i style={{ width: `${Math.max(0, Math.min(100, row.share * 100))}%` }} /></div>
                    <strong>{pct(row.share)}</strong>
                  </div>
                )) : <div className="muted">Нет живых организмов в итогах серии.</div>}
              </div>
            </Section>
          </div>

          <Section title="Все запуски" subtitle="Каждая строка — отдельный независимый эксперимент со своим начальным числом">
            <div className="sampling-results-table">
              <div className="sampling-table-head"><span>№</span><span>Нач. число</span><span>Тики</span><span>Поп.</span><span>Рожд.</span><span>Смерт.</span><span>Покол.</span><span>Эфф.</span><span>Энтропия</span></div>
              {result.results.map(row => (
                <div className="sampling-table-row" key={`${row.run}-${row.seed}`}>
                  <span>{String(row.run).padStart(2, '0')}</span><b>{row.seed}</b><span>{row.ticksCompleted}</span><span>{row.population}</span><span>{row.births}</span><span>{row.deaths}</span><span>{row.generation}</span><span>{pct(row.efficiency)}</span><span>{num(row.entropy)}</span>
                </div>
              ))}
            </div>
          </Section>

          <Section title="Воспроизводимость" subtitle="Проверка выполняется автоматически на первом начальном числе серии.">
            <div className="repro-box">
              <div className={`repro-mark ${result.reproducibility.verified ? 'good' : 'bad'}`}>{result.reproducibility.verified ? '✓' : '!'}</div>
              <div><b>{result.reproducibility.verified ? 'Одинаковое начальное число дало одинаковый результат' : 'Проверка воспроизводимости не пройдена'}</b><p>{result.reproducibility.method}. Проверенное число: <code>{result.reproducibility.checkedSeed}</code>.</p></div>
            </div>
          </Section>
        </>
      )}
    </div>
  )
}
