import React from 'react'
import { EmptyState, Progress, Section, StatusPill } from '../components/Ui'

const labels = {
  resource_drive: 'поиск ресурсов', water_drive: 'поиск воды', safety_drive: 'осторожность', exploration_drive: 'исследование', rest_drive: 'отдых', reproduction_drive: 'размножение', memory_weight: 'влияние памяти', risk_tolerance: 'терпимость к риску', adaptation_rate: 'скорость адаптации',
}

export default function Inspector({ state }) {
  const o = state.selected
  if (!o) return <EmptyState title="Живая сущность не выбрана" text="Вернитесь в «Обзор» и нажмите на точку организма на карте." />
  return (
    <div className="page-grid">
      <div className="hero-row"><div><div className="page-kicker">ИНСПЕКТОР · СУЩНОСТЬ #{o.id}</div><h2 className="page-title">Профиль организма</h2><p className="page-description">Состояние, происхождение, память и параметры, влияющие на выбор.</p></div><StatusPill tone="good">ЖИВАЯ</StatusPill></div>
      <div className="two-column inspector-columns">
        <Section title={`Сущность #${o.id}`} subtitle={`координаты (${o.x}, ${o.y}) · поколение ${o.generation}`}>
          <div className="entity-stats">
            <Progress label="Энергия" value={o.energy} />
            <Progress label="Гидратация" value={o.hydration} />
            <Progress label="Здоровье" value={o.health} />
            <Progress label="Память" value={o.memory} />
          </div>
          <div className="key-value"><span>Последнее действие</span><b>{o.lastAction}</b></div>
          <div className="key-value"><span>Последнее вознаграждение</span><b>{o.lastReward >= 0 ? '+' : ''}{o.lastReward}</b></div>
          <div className="key-value"><span>Родитель</span><b>{o.parentId ?? '—'}</b></div>
          <div className="key-value"><span>Потомков</span><b>{o.children}</b></div>
          <div className="key-value"><span>Возраст</span><b>{o.age}</b></div>
          <div className="key-value"><span>Перезарядка размножения</span><b>{o.cooldown}</b></div>
        </Section>
        <Section title="Геном" subtitle="Наследуемые поведенческие параметры">
          <div className="genome-list">{Object.entries(o.genome).map(([key, value]) => <div key={key} className="genome-row"><span>{labels[key] || key}</span><div className="mini-track"><i style={{width:`${value*100}%`}} /></div><b>{value.toFixed(3)}</b></div>)}</div>
        </Section>
      </div>
      <Section title="Почему выбрано это действие" subtitle="Разбор альтернатив для последнего решения организма">
        {state.decision ? <div className="decision-grid">
          <div className="decision-selected"><span>ВЫБРАНО</span><strong>{state.decision.action}</strong><small>память {o.memory}% · риск {o.genome.risk_tolerance.toFixed(3)} · вознаграждение {o.lastReward >= 0 ? '+' : ''}{o.lastReward}</small></div>
          <div className="decision-scores">{state.decision.scores.map((row, i) => <div key={row.action} className={`decision-row ${i === 0 ? 'top' : ''}`}><span>{String(i+1).padStart(2,'0')}</span><b>{row.action}</b><em>{row.score.toFixed(3)}</em></div>)}</div>
        </div> : <div className="empty-inline">Решение ещё не рассчитано. Запустите симуляцию или сделайте один шаг.</div>}
      </Section>
    </div>
  )
}
