import React, { useMemo } from 'react'

function points(data, key, max, width, height, padX = 34, padTop = 30, padBottom = 24) {
  if (!data.length) return ''
  const innerW = width - padX * 2
  const innerH = height - padTop - padBottom
  return data.map((row, i) => {
    const x = padX + (i / Math.max(1, data.length - 1)) * innerW
    const y = padTop + innerH - (Number(row[key]) / Math.max(1, max)) * innerH
    return `${x.toFixed(1)},${y.toFixed(1)}`
  }).join(' ')
}

const LEGEND = [
  ['chart-population', 'ПОПУЛЯЦИЯ'],
  ['chart-capacity', 'ЁМКОСТЬ'],
  ['chart-generation', 'ПОКОЛЕНИЯ'],
]

export default function Chart({ history }) {
  const width = 900
  const height = 280
  const data = useMemo(() => history.slice(-160), [history])

  if (data.length < 2) return <div className="chart-empty">График появится после первого шага симуляции.</div>

  const maxPopulation = Math.max(1, ...data.map(d => Math.max(d.population, d.capacity)))
  const maxGeneration = Math.max(1, ...data.map(d => d.generation))

  return (
    <div className="chart-wrap">
      <div className="chart-legend" aria-label="Обозначения графика">
        {LEGEND.map(([className, label]) => (
          <span key={label} className="chart-legend-item">
            <i className={`chart-legend-line ${className}`} />
            {label}
          </span>
        ))}
      </div>
      <div className="chart-canvas">
        <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="chart-svg" role="img" aria-label="Динамика популяции, экологической ёмкости и поколений во времени">
          {[1, 2, 3, 4].map(i => <line key={i} x1="34" x2={width - 34} y1={30 + ((height - 54) * i / 4)} y2={30 + ((height - 54) * i / 4)} className="grid-line" />)}
          <polyline points={points(data, 'capacity', maxPopulation, width, height)} className="chart-capacity" />
          <polyline points={points(data, 'population', maxPopulation, width, height)} className="chart-population" />
          <polyline points={points(data, 'generation', maxGeneration, width, height)} className="chart-generation" />
          <text x="36" y={height - 7} className="chart-tick">тик {data[0].tick}</text>
          <text x={width - 36} y={height - 7} textAnchor="end" className="chart-tick">тик {data.at(-1).tick}</text>
        </svg>
      </div>
    </div>
  )
}
