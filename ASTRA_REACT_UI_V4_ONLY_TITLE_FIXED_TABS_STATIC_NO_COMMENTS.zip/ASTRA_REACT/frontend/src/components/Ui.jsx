import React from 'react'

export function Section({ title, subtitle, action, children, className = '' }) {
  return (
    <section className={`section ${className}`}>
      <div className="section-head">
        <div>
          <h2>{title}</h2>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  )
}

export function MetricCard({ label, value, detail, tone = 'blue', icon }) {
  return (
    <div className={`metric-card tone-${tone}`}>
      <div className="metric-top">
        <span className="metric-icon">{icon}</span>
        <span>{label}</span>
      </div>
      <strong>{value}</strong>
      {detail && <small>{detail}</small>}
    </div>
  )
}

export function Progress({ value, label, sublabel }) {
  const safe = Math.max(0, Math.min(100, Number(value) || 0))
  return (
    <div className="progress-wrap">
      <div className="progress-label">
        <span>{label}</span>
        <span>{Math.round(safe)}%</span>
      </div>
      <div className="progress-track"><div className="progress-fill" style={{ width: `${safe}%` }} /></div>
      {sublabel && <small>{sublabel}</small>}
    </div>
  )
}

export function NumericField({ label, value, min = 0, max = 2147483647, step = 1, onChange, hint }) {
  return (
    <label className="numeric-field">
      <div className="slider-heading"><span>{label}</span><b>число</b></div>
      <input type="number" min={min} max={max} step={step} value={value} onChange={e => onChange(Number(e.target.value))} />
      {hint && <span className="field-hint">{hint}</span>}
    </label>
  )
}

export function SliderField({ label, value, min = 0, max = 100, step = 1, suffix = '%', onChange, hint }) {
  return (
    <label className="slider-field">
      <div className="slider-heading">
        <span>{label}</span>
        <b>{Number(value).toFixed(step < 1 ? 1 : 0)}{suffix}</b>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={e => onChange(Number(e.target.value))} />
      {hint && <span className="field-hint">{hint}</span>}
    </label>
  )
}

export function StatusPill({ children, tone = 'neutral' }) {
  return <span className={`status-pill ${tone}`}>{children}</span>
}

export function ActionButton({ children, onClick, variant = 'secondary', disabled = false, title }) {
  return <button className={`action-button ${variant}`} onClick={onClick} disabled={disabled} title={title}>{children}</button>
}

export function EmptyState({ title, text }) {
  return <div className="empty-state"><div className="empty-mark">◌</div><h3>{title}</h3><p>{text}</p></div>
}
