import random
import math
import json
from collections import Counter, defaultdict







WINDOW_W = 1480
WINDOW_H = 860
MIN_W = 1240
MIN_H = 720
TICK_MS = 80
MAX_POP = 420  
INITIAL_POP = 80
GRID_W, GRID_H = 18, 12


ACTION_FILL = {
    "ИСКАТЬ РЕСУРСЫ": "#a9e6a2",
    "ИСКАТЬ ВОДУ": "#9edcf2",
    "УКРЫТЬСЯ": "#d9b8f0",
    "ИССЛЕДОВАТЬ": "#f2c27b",
    "ОТДЫХАТЬ": "#c5d0d8",
    "ВОСПРОИЗВЕСТИСЬ": "#f2a6c7",
    "ОЖИДАНИЕ": "#dce7ed",
}

BIOME_SHORT = {
    "ОАЗИС": "О",
    "ПУСТЫНЯ": "П",
    "ЛЕДНИК": "Л",
    "АНОМАЛИЯ": "А",
}

ACTIONS = [
    "ИСКАТЬ РЕСУРСЫ",
    "ИСКАТЬ ВОДУ",
    "УКРЫТЬСЯ",
    "ИССЛЕДОВАТЬ",
    "ОТДЫХАТЬ",
    "ВОСПРОИЗВЕСТИСЬ",
]

BIOMES = {
    "ОАЗИС": {"resource": 0.95, "water": 0.95, "radiation": 0.12, "temp": 0.35},
    "ПУСТЫНЯ": {"resource": 0.45, "water": 0.12, "radiation": 0.42, "temp": 0.82},
    "ЛЕДНИК": {"resource": 0.18, "water": 0.80, "radiation": 0.25, "temp": 0.08},
    "АНОМАЛИЯ": {"resource": 0.65, "water": 0.50, "radiation": 0.88, "temp": 0.50},
}

BIOME_FILL = {
    "ОАЗИС": "#28513f",
    "ПУСТЫНЯ": "#5a4929",
    "ЛЕДНИК": "#29495f",
    "АНОМАЛИЯ": "#5a315f",
}

BIOME_RU = {
    "ОАЗИС": "ОАЗИС",
    "ПУСТЫНЯ": "ПУСТЫНЯ",
    "ЛЕДНИК": "ЛЕДНИК",
    "АНОМАЛИЯ": "АНОМАЛИЯ",
}


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def percent(x):
    return int(round(clamp(x) * 100))


class Cell:
    def __init__(self, biome):
        self.biome = biome
        b = BIOMES[biome]
        self.resources = clamp(b["resource"] * random.uniform(0.68, 1.0))
        self.water = clamp(b["water"] * random.uniform(0.68, 1.0))
        self.radiation = clamp(b["radiation"] + random.uniform(-0.07, 0.07))
        self.temperature = clamp(b["temp"] + random.uniform(-0.07, 0.07))
        self.damage = 0.0

    def regenerate(self, global_resource=0.6, global_water=0.6, stability=0.7):
        
        
        rates = {
            "ОАЗИС": (0.0090, 0.0130),
            "ПУСТЫНЯ": (0.0055, 0.0060),
            "ЛЕДНИК": (0.0065, 0.0100),
            "АНОМАЛИЯ": (0.0030, 0.0040),
        }
        resource_rate, water_rate = rates[self.biome]
        recovery_factor = 0.55 + global_resource * 0.45 + stability * 0.20
        water_factor = 0.55 + global_water * 0.45 + stability * 0.20
        self.resources = clamp(self.resources + resource_rate * recovery_factor)
        self.water = clamp(self.water + water_rate * water_factor)
        self.damage = max(0.0, self.damage - 0.0035 * (0.55 + stability * 0.45))


class Planet:
    def __init__(self, settings=None):
        settings = settings or {}
        self.temperature = clamp(settings.get("temperature", 0.48))
        self.water = clamp(settings.get("water", 0.53))
        self.radiation = clamp(settings.get("radiation", 0.28))
        self.resources = clamp(settings.get("resources", 0.62))
        self.energy = clamp(settings.get("energy", 0.60))
        self.stability = clamp(settings.get("stability", 0.72))
        self.solar_activity = clamp(settings.get("solar_activity", 0.30))

        self.base_temperature = self.temperature
        self.base_water = self.water
        self.base_radiation = self.radiation
        self.base_resources = self.resources
        self.base_energy = self.energy
        self.base_stability = self.stability
        self.base_solar_activity = self.solar_activity
        self.storm = 0.0
        self.age = 0
        self.event = "ИНИЦИАЛИЗАЦИЯ"
        self.cells = self._make_world()
        self._apply_global_conditions()

    def _make_world(self):
        
        
        
        cells = []
        anomaly_cells = set()
        anomaly_target = max(8, int(GRID_W * GRID_H * 0.055))
        while len(anomaly_cells) < anomaly_target:
            anomaly_cells.add((random.randrange(GRID_W), random.randrange(GRID_H)))

        for y in range(GRID_H):
            row = []
            for x in range(GRID_W):
                if (x, y) in anomaly_cells:
                    biome = "АНОМАЛИЯ"
                else:
                    north = y / max(1, GRID_H - 1)
                    if north < 0.25:
                        biome = "ЛЕДНИК" if random.random() < 0.84 else "ОАЗИС"
                    elif north > 0.72:
                        biome = "ПУСТЫНЯ" if random.random() < 0.84 else "ОАЗИС"
                    else:
                        biome = "ОАЗИС" if random.random() < 0.72 else "ПУСТЫНЯ"
                row.append(Cell(biome))
            cells.append(row)
        return cells

    def _apply_global_conditions(self):
        for row in self.cells:
            for cell in row:
                
                cell.temperature = clamp(cell.temperature * 0.62 + self.temperature * 0.38)
                cell.water = clamp(cell.water * 0.52 + self.water * 0.48)
                cell.resources = clamp(cell.resources * 0.52 + self.resources * 0.48)
                cell.radiation = clamp(cell.radiation * 0.58 + self.radiation * 0.42)

    def set_parameters(self, settings):
        old_temperature = self.temperature
        old_water = self.water
        old_resources = self.resources
        old_radiation = self.radiation

        self.temperature = clamp(settings["temperature"])
        self.water = clamp(settings["water"])
        self.resources = clamp(settings["resources"])
        self.radiation = clamp(settings["radiation"])
        self.energy = clamp(settings["energy"])
        self.stability = clamp(settings["stability"])
        self.solar_activity = clamp(settings["solar_activity"])

        self.base_temperature = self.temperature
        self.base_water = self.water
        self.base_resources = self.resources
        self.base_radiation = self.radiation
        self.base_energy = self.energy
        self.base_stability = self.stability
        self.base_solar_activity = self.solar_activity

        d_temperature = (self.temperature - old_temperature) * 0.35
        d_water = (self.water - old_water) * 0.30
        d_resources = (self.resources - old_resources) * 0.30
        d_radiation = (self.radiation - old_radiation) * 0.32

        for row in self.cells:
            for cell in row:
                cell.temperature = clamp(cell.temperature + d_temperature)
                cell.water = clamp(cell.water + d_water)
                cell.resources = clamp(cell.resources + d_resources)
                cell.radiation = clamp(cell.radiation + d_radiation)

    def get_cell(self, x, y):
        x = max(0, min(GRID_W - 1, int(x)))
        y = max(0, min(GRID_H - 1, int(y)))
        return self.cells[y][x]

    def average_cell_stats(self):
        all_cells = [c for row in self.cells for c in row]
        return (
            sum(c.resources for c in all_cells) / len(all_cells),
            sum(c.water for c in all_cells) / len(all_cells),
            sum(c.radiation for c in all_cells) / len(all_cells),
            sum(c.temperature for c in all_cells) / len(all_cells),
        )

    def trigger_storm(self, intensity=None):
        self.storm = clamp(intensity if intensity is not None else random.uniform(0.55, 0.90))
        self.solar_activity = clamp(self.solar_activity + self.storm * 0.30)
        self.radiation = clamp(self.radiation + self.storm * 0.24)
        self.stability = clamp(self.stability - self.storm * 0.13)
        self.event = f"СОЛНЕЧНАЯ БУРЯ: интенсивность {self.storm:.2f}"

        for row in self.cells:
            for cell in row:
                chance = 0.28 if cell.biome != "АНОМАЛИЯ" else 0.72
                if random.random() < chance:
                    cell.radiation = clamp(cell.radiation + self.storm * 0.18)
                    cell.damage = clamp(cell.damage + self.storm * 0.12)

    def climate_shift(self, delta=None):
        delta = delta if delta is not None else random.uniform(-0.10, 0.10)
        self.temperature = clamp(self.temperature + delta)
        
        
        self.water = clamp(self.water - delta * 0.16)
        self.stability = clamp(self.stability - abs(delta) * 0.30)
        self.event = f"ИЗМЕНЕНИЕ КЛИМАТА: ΔT {delta:+.2f}"

        for row in self.cells:
            for cell in row:
                cell.temperature = clamp(cell.temperature + delta * 0.45)
                cell.water = clamp(cell.water - delta * 0.08)

    def step(self, population_pressure=0.0):
        self.age += 1
        self.event = ""

        
        self.solar_activity = clamp(
            self.solar_activity * 0.985
            + self.base_solar_activity * 0.015
            + random.uniform(-0.008, 0.008)
        )
        self.storm = max(0.0, self.storm - 0.028)

        avg_r, avg_w, avg_rad, avg_t = self.average_cell_stats()

        self.temperature = clamp(
            self.temperature * 0.975
            + self.base_temperature * 0.019
            + avg_t * 0.006
            + random.uniform(-0.0025, 0.0025)
        )
        self.water = clamp(
            self.water * 0.992
            + self.base_water * 0.005
            + avg_w * 0.003
            - population_pressure * 0.00005
        )
        self.resources = clamp(
            self.resources * 0.992
            + self.base_resources * 0.005
            + avg_r * 0.003
            - population_pressure * 0.00007
        )
        self.radiation = clamp(
            self.radiation * 0.987
            + self.base_radiation * 0.010
            + avg_rad * 0.002
            + self.solar_activity * 0.00025
        )
        self.energy = clamp(self.energy * 0.995 + self.base_energy * 0.005)
        self.stability = clamp(
            self.stability * 0.9945
            + self.base_stability * 0.0055
            - max(0.0, population_pressure - 0.75) * 0.001
        )

        for row in self.cells:
            for cell in row:
                cell.regenerate(self.resources, self.water, self.stability)

        if self.age > 50 and random.random() < 0.0028 * (0.65 + self.solar_activity):
            self.trigger_storm()
        elif self.age > 100 and random.random() < 0.0020:
            self.climate_shift()


class Genome:
    KEYS = [
        "resource_drive",
        "water_drive",
        "safety_drive",
        "exploration_drive",
        "rest_drive",
        "reproduction_drive",
        "memory_weight",
        "risk_tolerance",
        "adaptation_rate",
    ]

    LABELS = {
        "resource_drive": "поиск ресурсов",
        "water_drive": "поиск воды",
        "safety_drive": "осторожность",
        "exploration_drive": "исследование",
        "rest_drive": "отдых",
        "reproduction_drive": "размножение",
        "memory_weight": "влияние памяти",
        "risk_tolerance": "терпимость к риску",
        "adaptation_rate": "скорость адаптации",
    }

    def __init__(self, values=None):
        if values is None:
            self.values = {k: random.uniform(0.25, 0.75) for k in self.KEYS}
        else:
            self.values = dict(values)

    def mutate(self, strength=0.06):
        return Genome({
            key: clamp(value + random.gauss(0, strength))
            for key, value in self.values.items()
        })

    def distance(self, other):
        return sum(
            abs(self.values[k] - other.values[k]) for k in self.KEYS
        ) / len(self.KEYS)


class Decision:
    def __init__(self, action, scores):
        self.action = action
        self.scores = scores


class Organism:
    next_id = 1

    def __init__(self, x, y, genome=None, generation=0, parent_id=None):
        self.id = Organism.next_id
        Organism.next_id += 1
        self.x = x
        self.y = y
        self.genome = genome or Genome()
        self.generation = generation
        self.parent_id = parent_id
        self.age = 0
        self.energy = random.uniform(0.68, 0.88)
        self.hydration = random.uniform(0.68, 0.88)
        self.health = random.uniform(0.94, 1.0)
        self.memory = 0.5
        self.last_action = "ОЖИДАНИЕ"
        self.last_reward = 0.0
        self.alive = True
        self.children = 0
        self.total_actions = 0
        self.successes = 0
        self.last_decision = None
        self.reproduction_cooldown = random.randint(0, 90)

    def sense(self, planet):
        cell = planet.get_cell(self.x, self.y)
        danger = clamp(cell.radiation * 0.68 + cell.damage * 0.32)
        temperature_stress = clamp(abs(cell.temperature - 0.52) * 1.45)
        return {
            "resource": cell.resources,
            "water": cell.water,
            "danger": danger,
            "scarcity": 1.0 - cell.resources,
            "thirst": 1.0 - self.hydration,
            "hunger": 1.0 - self.energy,
            "cold": max(0.0, 0.22 - cell.temperature) / 0.22,
            "heat": max(0.0, cell.temperature - 0.72) / 0.28,
            "temperature_stress": temperature_stress,
            "stability": planet.stability,
        }

    def _reproduction_environment_score(self, planet):
        cell = planet.get_cell(self.x, self.y)
        local_safety = 1.0 - clamp(cell.radiation * 0.75 + cell.damage * 0.25)
        local_thermal = 1.0 - min(1.0, abs(cell.temperature - 0.52) * 1.65)
        local_balance = math.sqrt(max(0.0, cell.resources * cell.water))
        local_quality = clamp(
            local_balance * 0.46
            + local_safety * 0.18
            + local_thermal * 0.10
            + planet.stability * 0.08
            + planet.energy * 0.08
            + (0.10 * math.sqrt(max(0.0, planet.resources * planet.water)))
        )

        global_safety = 1.0 - clamp(planet.radiation)
        global_thermal = 1.0 - min(1.0, abs(planet.temperature - 0.52) * 1.50)
        global_balance = math.sqrt(max(0.0, planet.resources * planet.water))
        global_quality = clamp(
            global_balance * 0.50
            + global_safety * 0.20
            + global_thermal * 0.10
            + planet.stability * 0.10
            + planet.energy * 0.10
        )
        return clamp(local_quality * 0.45 + global_quality * 0.55)

    def decide(self, planet, population_ratio=0.0):
        s = self.sense(planet)
        g = self.genome.values
        environment = self._reproduction_environment_score(planet)

        
        density_factor = clamp(1.0 - max(0.0, population_ratio - 0.35) / 0.90)

        scores = {
            "ИСКАТЬ РЕСУРСЫ": g["resource_drive"] * (
                0.22 + s["scarcity"] * 0.92 + s["hunger"] * 1.15
            ),
            "ИСКАТЬ ВОДУ": g["water_drive"] * (
                0.22 + s["thirst"] * 1.45 + (1.0 - s["water"]) * 0.95
            ),
            "УКРЫТЬСЯ": g["safety_drive"] * (
                0.10 + s["danger"] * 1.90 + s["heat"] * 0.35 + s["cold"] * 0.18
            ),
            "ИССЛЕДОВАТЬ": g["exploration_drive"] * (
                0.18 + s["stability"] * 0.60
            ) * (0.60 + g["risk_tolerance"]),
            "ОТДЫХАТЬ": g["rest_drive"] * (
                0.12 + max(0.0, 0.70 - self.energy) * 0.70
                + max(0.0, 0.68 - self.hydration) * 0.45
                + max(0.0, 0.78 - self.health) * 0.55
            ),
            "ВОСПРОИЗВЕСТИСЬ": 0.0,
        }

        
        memory_bias = self.memory * g["memory_weight"] * self.last_reward * 0.22
        if self.last_action in scores:
            scores[self.last_action] += memory_bias

        mature = clamp((self.age - 70.0) / 90.0)
        condition = min(
            clamp((self.energy - 0.55) / 0.40),
            clamp((self.hydration - 0.55) / 0.40),
            self.health,
        )
        readiness = mature * condition * environment * density_factor

        if (
            self.reproduction_cooldown <= 0
            and self.age >= 90
            and self.energy >= 0.72
            and self.hydration >= 0.70
            and self.health >= 0.78
            and environment >= 0.46
            and population_ratio < 0.93
        ):
            
            
            scores["ВОСПРОИЗВЕСТИСЬ"] = g["reproduction_drive"] * (
                0.045 + readiness * 0.62
            )
        else:
            scores["ВОСПРОИЗВЕСТИСЬ"] = 0.006

        scores["ИССЛЕДОВАТЬ"] *= 0.45 + 0.50 * g["risk_tolerance"]

        
        if self.hydration < 0.34:
            scores["ИСКАТЬ ВОДУ"] *= 2.10
            scores["ВОСПРОИЗВЕСТИСЬ"] = 0.006
        if self.energy < 0.34:
            scores["ИСКАТЬ РЕСУРСЫ"] *= 2.05
            scores["ВОСПРОИЗВЕСТИСЬ"] = 0.006
        if self.health < 0.45:
            scores["ОТДЫХАТЬ"] *= 1.70
            scores["УКРЫТЬСЯ"] *= 1.35
            scores["ВОСПРОИЗВЕСТИСЬ"] = 0.006
        if s["danger"] > 0.62 or planet.radiation > 0.72:
            scores["УКРЫТЬСЯ"] *= 1.90
            scores["ВОСПРОИЗВЕСТИСЬ"] = min(scores["ВОСПРОИЗВЕСТИСЬ"], 0.02)

        action = max(scores, key=scores.get)
        return Decision(action, scores)

    def _move_to_better_neighbor(self, planet, attribute):
        candidates = []
        for dx, dy in (
            (1, 0), (-1, 0), (0, 1), (0, -1),
            (1, 1), (1, -1), (-1, 1), (-1, -1),
        ):
            nx = self.x + dx
            ny = self.y + dy
            if 0 <= nx < GRID_W and 0 <= ny < GRID_H:
                c = planet.get_cell(nx, ny)
                value = getattr(c, attribute) - c.radiation * 0.48 - c.damage * 0.32
                candidates.append((value, nx, ny))
        if candidates:
            current = planet.get_cell(self.x, self.y)
            current_value = getattr(current, attribute) - current.radiation * 0.48 - current.damage * 0.32
            best = max(candidates)
            if best[0] > current_value + 0.035:
                _, self.x, self.y = best

    def _move_to_safer_neighbor(self, planet):
        candidates = []
        for dx, dy in (
            (1, 0), (-1, 0), (0, 1), (0, -1),
            (1, 1), (1, -1), (-1, 1), (-1, -1),
        ):
            nx = self.x + dx
            ny = self.y + dy
            if 0 <= nx < GRID_W and 0 <= ny < GRID_H:
                c = planet.get_cell(nx, ny)
                score = (
                    (1.0 - c.radiation) * 0.72
                    + (1.0 - c.damage) * 0.18
                    + c.water * 0.05
                    + c.resources * 0.05
                )
                candidates.append((score, nx, ny))
        if candidates:
            _, self.x, self.y = max(candidates)

    def act(self, planet, population_ratio=0.0):
        if not self.alive:
            return 0.0, None

        self.age += 1
        self.total_actions += 1
        self.reproduction_cooldown = max(0, self.reproduction_cooldown - 1)
        decision = self.decide(planet, population_ratio)
        self.last_decision = decision
        action = decision.action
        cell = planet.get_cell(self.x, self.y)

        old_energy = self.energy
        old_hydration = self.hydration
        reward = -0.008

        
        
        self.energy -= 0.0022 + cell.temperature * 0.0005
        self.hydration -= 0.0016 + max(0.0, cell.temperature - 0.60) * 0.0028

        competition = 1.0 - min(0.30, max(0.0, population_ratio - 0.25) * 0.30)

        if action == "ИСКАТЬ РЕСУРСЫ":
            resource_factor = 0.20 + 0.80 * planet.resources
            amount = min(cell.resources, (0.045 + 0.035 * random.random()) * competition * resource_factor)
            cell.resources = clamp(cell.resources - amount)
            energy_conversion = 0.78 + planet.energy * 0.20
            self.energy = clamp(self.energy + amount * energy_conversion)
            reward = amount * (1.05 + planet.energy * 0.20) - 0.010
            self.successes += int(amount > 0.028)
            if cell.resources < 0.30 or amount < 0.035 or random.random() < 0.16:
                self._move_to_better_neighbor(planet, "resources")

        elif action == "ИСКАТЬ ВОДУ":
            water_factor = 0.20 + 0.80 * planet.water
            amount = min(cell.water, (0.050 + 0.040 * random.random()) * competition * water_factor)
            cell.water = clamp(cell.water - amount)
            self.hydration = clamp(self.hydration + amount)
            reward = amount * 1.18 - 0.010
            self.successes += int(amount > 0.032)
            if cell.water < 0.30 or amount < 0.040 or random.random() < 0.16:
                self._move_to_better_neighbor(planet, "water")

        elif action == "УКРЫТЬСЯ":
            self.energy -= 0.0010
            self.health = clamp(self.health + (0.0045 if cell.radiation < 0.42 and cell.damage < 0.25 else 0.0015))
            if cell.radiation > 0.60:
                self._move_to_safer_neighbor(planet)
            reward = 0.028 if cell.radiation > 0.45 else 0.006

        elif action == "ИССЛЕДОВАТЬ":
            self.energy -= 0.012
            self.hydration -= 0.007
            
            
            candidates = []
            for dx, dy in (
                (1, 0), (-1, 0), (0, 1), (0, -1),
                (1, 1), (1, -1), (-1, 1), (-1, -1),
            ):
                nx, ny = self.x + dx, self.y + dy
                if 0 <= nx < GRID_W and 0 <= ny < GRID_H:
                    c = planet.get_cell(nx, ny)
                    score = c.resources * 0.38 + c.water * 0.38 + (1.0 - c.radiation) * 0.24
                    candidates.append((score, nx, ny))
            if candidates and random.random() < 0.72:
                _, self.x, self.y = max(candidates)
            elif candidates:
                _, self.x, self.y = random.choice(candidates)
            new_cell = planet.get_cell(self.x, self.y)
            discovery = (new_cell.resources + new_cell.water) * 0.055
            reward = discovery - new_cell.radiation * 0.025

        elif action == "ОТДЫХАТЬ":
            self.energy = clamp(self.energy + 0.006)
            self.hydration = clamp(self.hydration + 0.001)
            self.health = clamp(self.health + 0.007)
            reward = 0.014

        elif action == "ВОСПРОИЗВЕСТИСЬ":
            reward = 0.010

        
        radiation_stress = max(0.0, cell.radiation - 0.25)
        heat_stress = max(0.0, cell.temperature - 0.76)
        cold_stress = max(0.0, 0.20 - cell.temperature)
        deprivation = max(0.0, 0.25 - self.energy) + max(0.0, 0.25 - self.hydration)

        self.health -= radiation_stress * 0.0036
        self.health -= cell.damage * 0.0022
        self.health -= heat_stress * 0.0038
        self.health -= cold_stress * 0.0028
        self.health -= deprivation * 0.011

        
        global_scarcity = max(0.0, 0.34 - math.sqrt(max(0.0, planet.resources * planet.water)))
        self.health -= global_scarcity * 0.0018

        
        
        safe_recovery = max(0.0, 0.55 - cell.radiation) * 0.0015
        self.health = clamp(self.health + safe_recovery)

        
        if self.age > 2500:
            self.health -= min(0.00008, (self.age - 3200) * 0.000000035)

        self.energy = clamp(self.energy)
        self.hydration = clamp(self.hydration)
        self.health = clamp(self.health)

        reward += (
            (self.energy - old_energy) * 0.35
            + (self.hydration - old_hydration) * 0.35
        )

        lr = 0.009 * self.genome.values["adaptation_rate"]
        self.memory = clamp(self.memory + reward * lr)

        if reward > 0:
            self.genome.values["adaptation_rate"] = clamp(
                self.genome.values["adaptation_rate"] + 0.00045
            )
        else:
            self.genome.values["risk_tolerance"] = clamp(
                self.genome.values["risk_tolerance"] - 0.00030
            )

        self.last_action = action
        self.last_reward = reward

        
        
        if (
            self.energy <= 0.002
            or self.hydration <= 0.002
            or self.health <= 0.03
            or self.age > 6500
        ):
            self.alive = False

        return reward, action

    def reproduction_readiness(self, planet, population_ratio=0.0):
        environment = self._reproduction_environment_score(planet)
        mature = clamp((self.age - 70.0) / 100.0)
        condition = min(
            clamp((self.energy - 0.55) / 0.40),
            clamp((self.hydration - 0.55) / 0.40),
            self.health,
        )
        density = clamp(1.0 - max(0.0, population_ratio - 0.35) / 0.90)
        return clamp(mature * condition * environment * density)

    def can_reproduce(self, planet=None, population_ratio=0.0):
        if not self.alive:
            return False
        if self.reproduction_cooldown > 0:
            return False
        if self.age < 90:
            return False
        if self.energy < 0.72 or self.hydration < 0.70 or self.health < 0.78:
            return False
        if population_ratio >= 0.93:
            return False
        if planet is not None and self._reproduction_environment_score(planet) < 0.46:
            return False
        return True

    def reproduce(self, mutation_strength, planet=None, population_ratio=0.0, approved=False):
        if not approved and not self.can_reproduce(planet, population_ratio):
            return None

        
        
        self.energy -= 0.085
        self.hydration -= 0.060
        self.reproduction_cooldown = 420

        child = Organism(
            self.x,
            self.y,
            self.genome.mutate(mutation_strength),
            generation=self.generation + 1,
            parent_id=self.id,
        )
        child.energy = random.uniform(0.40, 0.50)
        child.hydration = random.uniform(0.42, 0.53)
        child.health = random.uniform(0.84, 0.95)
        child.reproduction_cooldown = 120
        self.children += 1
        return child


def generate_seed():
    """Generate an experiment seed without consuming the simulation RNG stream."""
    return random.SystemRandom().randint(0, 2_147_483_647)


class Simulation:
    def __init__(self, settings=None, seed=None):
        self.settings = dict(settings or self.default_settings())
        requested_seed = seed if seed is not None else self.settings.get("seed")
        self.seed = int(requested_seed) if requested_seed is not None else generate_seed()
        self.settings["seed"] = self.seed
        self.mutation_strength = self.settings.get("mutation_strength", 0.055)
        self.initial_population = int(self.settings.get("initial_population", INITIAL_POP))
        self.reset()

    @staticmethod
    def default_settings():
        return {
            "temperature": 0.48,
            "water": 0.53,
            "resources": 0.62,
            "radiation": 0.28,
            "energy": 0.60,
            "stability": 0.72,
            "solar_activity": 0.30,
            "mutation_strength": 0.055,
            "initial_population": INITIAL_POP,
            "seed": generate_seed(),
        }

    def _spawn_location(self, used=None):
        used = used or set()
        candidates = []
        for y in range(GRID_H):
            for x in range(GRID_W):
                cell = self.planet.get_cell(x, y)
                global_resource_factor = 0.35 + 0.65 * self.planet.resources
                global_water_factor = 0.35 + 0.65 * self.planet.water
                suitability = (
                    cell.resources * global_resource_factor * 0.34
                    + cell.water * global_water_factor * 0.34
                    + (1.0 - cell.radiation) * 0.22
                    + (1.0 - cell.damage) * 0.10
                )
                if (x, y) in used:
                    suitability *= 0.55
                candidates.append((suitability, x, y))
        candidates.sort(reverse=True)
        top = candidates[:max(20, len(candidates) // 2)]
        _, x, y = random.choice(top)
        return x, y

    def reset(self):
        
        
        random.seed(self.seed)
        Organism.next_id = 1
        self.planet = Planet(self.settings)
        self.population = []
        used = set()
        for _ in range(self.initial_population):
            x, y = self._spawn_location(used)
            used.add((x, y))
            self.population.append(Organism(x, y))
        self.tick = 0
        self.births = self.initial_population
        self.deaths = 0
        self.max_generation = 0
        self.history = []
        self.journal = []
        self.selected_id = self.population[0].id if self.population else None
        self.last_decision = None
        self.before_snapshot = self.snapshot("НАЧАЛО")
        self.after_snapshot = None
        self._log("ПЛАНЕТА A-17 ИНИЦИАЛИЗИРОВАНА")
        self._log(f"СОЗДАНО ОСОБЕЙ: {len(self.population)}")

    def _log(self, text):
        self.journal.append(f"[{self.tick:05d}] {text}")
        self.journal = self.journal[-150:]

    def snapshot(self, label):
        alive = [o for o in self.population if o.alive]
        energies = [o.energy for o in alive]
        health = [o.health for o in alive]
        return {
            "label": label,
            "tick": self.tick,
            "population": len(alive),
            "generation": self.max_generation,
            "capacity": self.carrying_capacity(),
            "avg_energy": sum(energies) / len(energies) if energies else 0,
            "avg_health": sum(health) / len(health) if health else 0,
            "planet_resources": self.planet.resources,
            "planet_water": self.planet.water,
            "planet_radiation": self.planet.radiation,
            "entropy": self.entropy(),
        }

    def entropy(self):
        alive = [o for o in self.population if o.alive]
        if not alive:
            return 0.0
        counts = Counter(o.last_action for o in alive)
        total = sum(counts.values())
        if total <= 0:
            return 0.0
        return -sum(
            (n / total) * math.log2(n / total)
            for n in counts.values()
            if n
        )

    def carrying_capacity(self):
        
        
        avg_resources, avg_water, avg_radiation, avg_temperature = self.planet.average_cell_stats()

        local_balance = math.sqrt(max(0.0, avg_resources * avg_water))
        local_safety = 1.0 - clamp(avg_radiation * 0.90)
        local_thermal = 1.0 - min(1.0, abs(avg_temperature - 0.52) * 1.55)
        local_quality = clamp(
            local_balance * 0.52
            + local_safety * 0.18
            + self.planet.stability * 0.10
            + self.planet.energy * 0.08
            + local_thermal * 0.12
        )

        global_balance = math.sqrt(max(0.0, self.planet.base_resources * self.planet.base_water))
        global_safety = 1.0 - clamp(self.planet.base_radiation)
        global_thermal = 1.0 - min(1.0, abs(self.planet.base_temperature - 0.52) * 1.50)
        global_quality = clamp(
            global_balance * 0.50
            + global_safety * 0.19
            + self.planet.base_stability * 0.11
            + self.planet.base_energy * 0.09
            + global_thermal * 0.11
        )

        quality = clamp(global_quality * 0.68 + local_quality * 0.32)
        minimum_capacity = 20
        maximum_ecological_capacity = 340
        return int(
            minimum_capacity
            + (maximum_ecological_capacity - minimum_capacity) * quality
        )

    def behavioral_diversity(self):
        alive = [o for o in self.population if o.alive]
        if len(alive) < 2:
            return 0.0
        sample = alive[:40]
        pair_count = min(180, len(sample) * (len(sample) - 1) // 2)
        values = []
        for _ in range(pair_count):
            a, b = random.sample(sample, 2)
            values.append(a.genome.distance(b.genome))
        return sum(values) / len(values) if values else 0.0

    def step(self):
        alive_before = [o for o in self.population if o.alive]
        if not alive_before:
            self._log("ВЫМИРАНИЕ — СИМУЛЯЦИЯ ОСТАНОВЛЕНА")
            self.after_snapshot = self.snapshot("КОНЕЦ")
            return

        newborns = []
        actions = Counter()
        total_latency = 0.0
        total_efficiency = 0.0
        capacity = self.carrying_capacity()
        population_ratio = len(alive_before) / max(1, capacity)

        for organism in alive_before:
            latency = 0.46 + len(ACTIONS) * 0.045 + organism.genome.values["memory_weight"] * 0.10
            total_latency += latency

            decision_before = organism.decide(self.planet, population_ratio)
            readiness = organism.reproduction_readiness(self.planet, population_ratio)
            approved_reproduction = (
                decision_before.action == "ВОСПРОИЗВЕСТИСЬ"
                and organism.can_reproduce(self.planet, population_ratio)
                and (len(alive_before) + len(newborns)) < capacity
            )

            reward, action = organism.act(self.planet, population_ratio)
            actions[action] += 1
            total_efficiency += max(0.0, reward + 0.06)

            if action == "ВОСПРОИЗВЕСТИСЬ" and approved_reproduction:
                
                
                free_space = clamp(1.0 - population_ratio)
                reproduction_chance = clamp(0.12 + readiness * 0.34 + free_space * 0.18)
                if random.random() > reproduction_chance:
                    continue
                if (len(alive_before) + len(newborns)) >= capacity:
                    continue
                child = organism.reproduce(
                    self.mutation_strength,
                    planet=self.planet,
                    population_ratio=population_ratio,
                    approved=True,
                )
                if child:
                    newborns.append(child)
                    self.births += 1
                    self._log(
                        f"РОЖДЕНИЕ #{child.id} ← #{organism.id}, поколение {child.generation}"
                    )

        deaths_now = sum(1 for o in alive_before if not o.alive)
        self.deaths += deaths_now
        for organism in alive_before:
            if not organism.alive:
                self._log(
                    f"СМЕРТЬ #{organism.id}, возраст {organism.age}, "
                    f"E={organism.energy:.2f} W={organism.hydration:.2f} H={organism.health:.2f}"
                )

        self.population.extend(newborns)
        alive_population = [o for o in self.population if o.alive]

        
        
        if len(alive_population) > MAX_POP:
            alive_population.sort(
                key=lambda o: (
                    o.health * 0.45
                    + o.energy * 0.35
                    + o.hydration * 0.20
                ),
                reverse=True,
            )
            self.population = alive_population[:MAX_POP]
        else:
            self.population = alive_population

        
        
        self.planet.step(population_pressure=population_ratio)
        if self.planet.event:
            self._log(self.planet.event)

        self.tick += 1
        alive = [o for o in self.population if o.alive]
        if alive:
            self.max_generation = max(o.generation for o in alive)
            avg_energy = sum(o.energy for o in alive) / len(alive)
            avg_health = sum(o.health for o in alive) / len(alive)
            power = clamp(avg_energy * 0.55 + avg_health * 0.45)
            efficiency = clamp(total_efficiency / max(1, len(alive)))
            latency = total_latency / max(1, len(alive))
        else:
            power = efficiency = latency = 0.0

        self.history.append({
            "tick": self.tick,
            "population": len(alive),
            "generation": self.max_generation,
            "capacity": self.carrying_capacity(),
            "power": power,
            "efficiency": efficiency,
            "entropy": self.entropy(),
            "latency": latency,
            "diversity": self.behavioral_diversity(),
            "temperature": self.planet.temperature,
            "water": self.planet.water,
            "resources": self.planet.resources,
            "radiation": self.planet.radiation,
        })
        self.history = self.history[-360:]

        if self.tick % 100 == 0:
            self._log(
                f"КОНТРОЛЬНАЯ ТОЧКА: популяция {len(alive)}, "
                f"ёмкость {self.carrying_capacity()}, поколение {self.max_generation}, "
                f"энтропия {self.entropy():.2f}"
            )

        if not alive:
            self.after_snapshot = self.snapshot("КОНЕЦ")
        elif self.tick % 500 == 0:
            self.after_snapshot = self.snapshot("КОНЕЦ")

        if self.selected_id and not any(o.id == self.selected_id for o in alive):
            self.selected_id = alive[0].id if alive else None

        self.last_decision = None
        selected = self.get_selected()
        if selected:
            self.last_decision = selected.last_decision

    def get_selected(self):
        for organism in self.population:
            if organism.id == self.selected_id and organism.alive:
                return organism
        return None

    def export(self, filename):
        data = {
            "проект": "ASTRA V4",
            "объект": "Планета A-17",
            "тик": self.tick,
            "настройки": self.settings,
            "параметры_эволюции": {
                "сила_мутации": self.mutation_strength,
                "начальная_популяция": self.initial_population,
                "seed": self.seed,
            },
            "планета": {
                "температура": self.planet.temperature,
                "вода": self.planet.water,
                "радиация": self.planet.radiation,
                "ресурсы": self.planet.resources,
                "энергия": self.planet.energy,
                "стабильность": self.planet.stability,
                "солнечная_активность": self.planet.solar_activity,
            },
            "популяция": [],
            "история": self.history,
            "начальный_снимок": self.before_snapshot,
            "финальный_снимок": self.after_snapshot,
            "журнал": self.journal,
        }

        for organism in self.population:
            data["популяция"].append({
                "id": organism.id,
                "родитель": organism.parent_id,
                "поколение": organism.generation,
                "x": organism.x,
                "y": organism.y,
                "возраст": organism.age,
                "энергия": organism.energy,
                "вода": organism.hydration,
                "здоровье": organism.health,
                "память": organism.memory,
                "последнее_действие": organism.last_action,
                "потомков": organism.children,
                "жива": organism.alive,
                "геном": organism.genome.values,
            })

        with open(filename, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)



